# Jira ticket bookmarker

This is a Firefox extension that just attempts to find the Jira ticket ID from the URL and bookmark it under an appropriate folder, if it does not already exist.

## How to use it

1. Install the plugin.
2. Go to the page that you want to bookmark and has a Jira ticket ID in its URL.
3. Click on the plugin icon.
4. The bookmark will be created under "Other Bookmarks" under the corresponding folder.
